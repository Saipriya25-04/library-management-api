package com.saipriya.library.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "loans", indexes = @Index(name = "idx_loan_due", columnList = "dueDate"))
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "book_id")
    private Book book;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "member_id")
    private Member member;

    @Column(nullable = false)
    private LocalDate borrowedOn;

    @Column(nullable = false)
    private LocalDate dueDate;

    private LocalDate returnedOn;

    protected Loan() {
    }

    public Loan(Book book, Member member, LocalDate borrowedOn, int loanDays) {
        this.book = book;
        this.member = member;
        this.borrowedOn = borrowedOn;
        this.dueDate = borrowedOn.plusDays(loanDays);
    }

    public void markReturned(LocalDate date) {
        this.returnedOn = date;
    }

    public boolean isReturned() {
        return returnedOn != null;
    }

    public boolean isOverdue(LocalDate today) {
        return !isReturned() && today.isAfter(dueDate);
    }

    public Long getId() { return id; }
    public Book getBook() { return book; }
    public Member getMember() { return member; }
    public LocalDate getBorrowedOn() { return borrowedOn; }
    public LocalDate getDueDate() { return dueDate; }
    public LocalDate getReturnedOn() { return returnedOn; }

    public void setId(Long id) { this.id = id; }
}
