package com.saipriya.library.repository;

import com.saipriya.library.entity.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BookRepository extends JpaRepository<Book, Long> {

    boolean existsByIsbn(String isbn);

    /**
     * Search books. Every filter is optional: a null value means "don't filter on this".
     * The keyword matches title, author, or ISBN.
     */
    @Query("""
            select b from Book b
            where (:q is null or lower(b.title) like lower(concat('%', :q, '%'))
                              or lower(b.author) like lower(concat('%', :q, '%'))
                              or b.isbn = :q)
              and (:genre is null or lower(b.genre) = lower(:genre))
              and (:availableOnly = false or b.availableCopies > 0)
            """)
    Page<Book> search(@Param("q") String q,
                      @Param("genre") String genre,
                      @Param("availableOnly") boolean availableOnly,
                      Pageable pageable);
}
