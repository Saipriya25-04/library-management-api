package com.saipriya.library.service;

import com.saipriya.library.dto.LoanDtos.LoanResponse;
import com.saipriya.library.entity.Book;
import com.saipriya.library.entity.Loan;
import com.saipriya.library.entity.Member;
import com.saipriya.library.exception.BusinessRuleException;
import com.saipriya.library.exception.NotFoundException;
import com.saipriya.library.repository.BookRepository;
import com.saipriya.library.repository.LoanRepository;
import com.saipriya.library.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.LocalDate;
import java.util.List;

/** Borrowing workflow: borrow, return, member history, overdue list. */
@Service
public class LoanService {

    private final LoanRepository loans;
    private final BookRepository books;
    private final MemberRepository members;
    private final Clock clock;
    private final int loanDays;
    private final int maxActiveLoans;

    public LoanService(LoanRepository loans, BookRepository books, MemberRepository members, Clock clock,
                       @Value("${library.loan-days}") int loanDays,
                       @Value("${library.max-active-loans}") int maxActiveLoans) {
        this.loans = loans;
        this.books = books;
        this.members = members;
        this.clock = clock;
        this.loanDays = loanDays;
        this.maxActiveLoans = maxActiveLoans;
    }

    @Transactional
    public LoanResponse borrow(Long memberId, Long bookId) {
        Member member = members.findById(memberId)
                .orElseThrow(() -> new NotFoundException("Member " + memberId + " not found"));
        Book book = books.findById(bookId)
                .orElseThrow(() -> new NotFoundException("Book " + bookId + " not found"));

        if (!member.isActive()) {
            throw new BusinessRuleException("Member account is inactive");
        }
        if (loans.countByMemberIdAndReturnedOnIsNull(memberId) >= maxActiveLoans) {
            throw new BusinessRuleException("Member already has the maximum of " + maxActiveLoans + " books on loan");
        }
        if (loans.existsByMemberIdAndBookIdAndReturnedOnIsNull(memberId, bookId)) {
            throw new BusinessRuleException("Member already has a copy of this book");
        }

        book.checkOut();   // throws if no copies left; @Version on Book guards concurrent checkouts
        LocalDate today = LocalDate.now(clock);
        Loan loan = loans.save(new Loan(book, member, today, loanDays));
        return LoanResponse.from(loan, today);
    }

    @Transactional
    public LoanResponse returnBook(Long loanId) {
        Loan loan = loans.findById(loanId)
                .orElseThrow(() -> new NotFoundException("Loan " + loanId + " not found"));
        if (loan.isReturned()) {
            throw new BusinessRuleException("This loan was already returned");
        }
        LocalDate today = LocalDate.now(clock);
        loan.markReturned(today);
        loan.getBook().checkIn();
        return LoanResponse.from(loan, today);
    }

    @Transactional(readOnly = true)
    public Page<LoanResponse> historyForMember(Long memberId, Pageable pageable) {
        if (!members.existsById(memberId)) {
            throw new NotFoundException("Member " + memberId + " not found");
        }
        LocalDate today = LocalDate.now(clock);
        return loans.findByMemberIdOrderByBorrowedOnDesc(memberId, pageable)
                .map(l -> LoanResponse.from(l, today));
    }

    @Transactional(readOnly = true)
    public List<LoanResponse> overdue() {
        LocalDate today = LocalDate.now(clock);
        return loans.findByReturnedOnIsNullAndDueDateBeforeOrderByDueDateAsc(today).stream()
                .map(l -> LoanResponse.from(l, today))
                .toList();
    }
}
