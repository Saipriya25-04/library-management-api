package com.saipriya.library.service;

import com.saipriya.library.dto.MemberDtos.CreateMemberRequest;
import com.saipriya.library.dto.MemberDtos.MemberResponse;
import com.saipriya.library.dto.MemberDtos.UpdateMemberRequest;
import com.saipriya.library.entity.Member;
import com.saipriya.library.exception.BusinessRuleException;
import com.saipriya.library.exception.NotFoundException;
import com.saipriya.library.repository.LoanRepository;
import com.saipriya.library.repository.MemberRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MemberService {

    private final MemberRepository members;
    private final LoanRepository loans;

    public MemberService(MemberRepository members, LoanRepository loans) {
        this.members = members;
        this.loans = loans;
    }

    @Transactional(readOnly = true)
    public Page<MemberResponse> list(String q, Pageable pageable) {
        Page<Member> page = (q == null || q.isBlank())
                ? members.findAll(pageable)
                : members.findByNameContainingIgnoreCaseOrEmailContainingIgnoreCase(q.trim(), q.trim(), pageable);
        return page.map(MemberResponse::from);
    }

    @Transactional(readOnly = true)
    public MemberResponse get(Long id) {
        return MemberResponse.from(find(id));
    }

    @Transactional
    public MemberResponse create(CreateMemberRequest req) {
        String email = req.email().trim().toLowerCase();
        if (members.existsByEmail(email)) {
            throw new BusinessRuleException("A member with email " + email + " already exists");
        }
        return MemberResponse.from(members.save(new Member(req.name().trim(), email, req.phone())));
    }

    @Transactional
    public MemberResponse update(Long id, UpdateMemberRequest req) {
        Member member = find(id);
        if (!req.active() && loans.existsByMemberIdAndReturnedOnIsNull(id)) {
            throw new BusinessRuleException("Member must return all books before being deactivated");
        }
        member.update(req.name().trim(), req.phone(), req.active());
        return MemberResponse.from(member);
    }

    Member find(Long id) {
        return members.findById(id).orElseThrow(() -> new NotFoundException("Member " + id + " not found"));
    }
}
