package com.saipriya.library.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "books", indexes = {
        @Index(name = "idx_book_title", columnList = "title"),
        @Index(name = "idx_book_author", columnList = "author")
})
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 13)
    private String isbn;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String author;

    private String genre;

    private Integer publishedYear;

    @Column(nullable = false)
    private int totalCopies;

    @Column(nullable = false)
    private int availableCopies;

    /** Optimistic locking: two loans of the last copy can't both succeed. */
    @Version
    private Long version;

    protected Book() {
    }

    public Book(String isbn, String title, String author, String genre, Integer publishedYear, int totalCopies) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.publishedYear = publishedYear;
        this.totalCopies = totalCopies;
        this.availableCopies = totalCopies;
    }

    public void update(String title, String author, String genre, Integer publishedYear, int newTotal) {
        int onLoan = totalCopies - availableCopies;
        if (newTotal < onLoan) {
            throw new IllegalStateException("Total copies cannot be less than the " + onLoan + " copies on loan");
        }
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.publishedYear = publishedYear;
        this.availableCopies = newTotal - onLoan;
        this.totalCopies = newTotal;
    }

    public void checkOut() {
        if (availableCopies == 0) {
            throw new IllegalStateException("No copies of '" + title + "' are available");
        }
        availableCopies--;
    }

    public void checkIn() {
        if (availableCopies < totalCopies) {
            availableCopies++;
        }
    }

    public boolean hasCopiesOnLoan() {
        return availableCopies < totalCopies;
    }

    public Long getId() { return id; }
    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getGenre() { return genre; }
    public Integer getPublishedYear() { return publishedYear; }
    public int getTotalCopies() { return totalCopies; }
    public int getAvailableCopies() { return availableCopies; }

    public void setId(Long id) { this.id = id; }
}
