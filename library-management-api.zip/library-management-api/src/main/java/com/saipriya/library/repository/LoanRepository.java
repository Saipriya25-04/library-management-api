package com.saipriya.library.repository;

import com.saipriya.library.entity.Loan;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface LoanRepository extends JpaRepository<Loan, Long> {

    long countByMemberIdAndReturnedOnIsNull(Long memberId);

    boolean existsByMemberIdAndBookIdAndReturnedOnIsNull(Long memberId, Long bookId);

    boolean existsByBookIdAndReturnedOnIsNull(Long bookId);

    boolean existsByMemberIdAndReturnedOnIsNull(Long memberId);

    @EntityGraph(attributePaths = {"book", "member"})
    Page<Loan> findByMemberIdOrderByBorrowedOnDesc(Long memberId, Pageable pageable);

    /** Avoids N+1 queries by fetching book and member with each loan. */
    @EntityGraph(attributePaths = {"book", "member"})
    List<Loan> findByReturnedOnIsNullAndDueDateBeforeOrderByDueDateAsc(LocalDate date);
}
