package com.saipriya.library.exception;

/** A request that is well-formed but breaks a library rule (no copies left, loan limit reached, ...). */
public class BusinessRuleException extends RuntimeException {
    public BusinessRuleException(String message) {
        super(message);
    }
}
