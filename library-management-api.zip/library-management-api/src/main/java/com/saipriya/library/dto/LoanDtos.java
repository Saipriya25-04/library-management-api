package com.saipriya.library.dto;

import com.saipriya.library.entity.Loan;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public final class LoanDtos {

    private LoanDtos() {
    }

    public record BorrowRequest(@NotNull Long memberId, @NotNull Long bookId) {
    }

    public record LoanResponse(
            Long id, Long bookId, String bookTitle, Long memberId, String memberName,
            LocalDate borrowedOn, LocalDate dueDate, LocalDate returnedOn, boolean overdue) {

        public static LoanResponse from(Loan l, LocalDate today) {
            return new LoanResponse(l.getId(), l.getBook().getId(), l.getBook().getTitle(),
                    l.getMember().getId(), l.getMember().getName(),
                    l.getBorrowedOn(), l.getDueDate(), l.getReturnedOn(), l.isOverdue(today));
        }
    }
}
