package com.saipriya.library.controller;

import com.saipriya.library.dto.LoanDtos.LoanResponse;
import com.saipriya.library.dto.MemberDtos.CreateMemberRequest;
import com.saipriya.library.dto.MemberDtos.MemberResponse;
import com.saipriya.library.dto.MemberDtos.UpdateMemberRequest;
import com.saipriya.library.dto.PageResponse;
import com.saipriya.library.service.LoanService;
import com.saipriya.library.service.MemberService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/members")
@Tag(name = "Members")
public class MemberController {

    private final MemberService memberService;
    private final LoanService loanService;

    public MemberController(MemberService memberService, LoanService loanService) {
        this.memberService = memberService;
        this.loanService = loanService;
    }

    @GetMapping
    public PageResponse<MemberResponse> list(@RequestParam(required = false) String q,
                                             @RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "20") int size) {
        var pageable = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by("name"));
        return PageResponse.from(memberService.list(q, pageable));
    }

    @GetMapping("/{id}")
    public MemberResponse get(@PathVariable Long id) {
        return memberService.get(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public MemberResponse create(@Valid @RequestBody CreateMemberRequest request) {
        return memberService.create(request);
    }

    @PutMapping("/{id}")
    public MemberResponse update(@PathVariable Long id, @Valid @RequestBody UpdateMemberRequest request) {
        return memberService.update(id, request);
    }

    @GetMapping("/{id}/loans")
    public PageResponse<LoanResponse> loans(@PathVariable Long id,
                                            @RequestParam(defaultValue = "0") int page,
                                            @RequestParam(defaultValue = "20") int size) {
        return PageResponse.from(loanService.historyForMember(id,
                PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100))));
    }
}
