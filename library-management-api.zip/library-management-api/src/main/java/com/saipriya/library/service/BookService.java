package com.saipriya.library.service;

import com.saipriya.library.dto.BookDtos.BookRequest;
import com.saipriya.library.dto.BookDtos.BookResponse;
import com.saipriya.library.entity.Book;
import com.saipriya.library.exception.BusinessRuleException;
import com.saipriya.library.exception.NotFoundException;
import com.saipriya.library.repository.BookRepository;
import com.saipriya.library.repository.LoanRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BookService {

    private final BookRepository books;
    private final LoanRepository loans;

    public BookService(BookRepository books, LoanRepository loans) {
        this.books = books;
        this.loans = loans;
    }

    @Transactional(readOnly = true)
    public Page<BookResponse> search(String q, String genre, boolean availableOnly, Pageable pageable) {
        return books.search(blankToNull(q), blankToNull(genre), availableOnly, pageable).map(BookResponse::from);
    }

    @Transactional(readOnly = true)
    public BookResponse get(Long id) {
        return BookResponse.from(find(id));
    }

    @Transactional
    public BookResponse create(BookRequest req) {
        if (books.existsByIsbn(req.isbn())) {
            throw new BusinessRuleException("A book with ISBN " + req.isbn() + " already exists");
        }
        Book book = new Book(req.isbn(), req.title().trim(), req.author().trim(),
                blankToNull(req.genre()), req.publishedYear(), req.totalCopies());
        return BookResponse.from(books.save(book));
    }

    @Transactional
    public BookResponse update(Long id, BookRequest req) {
        Book book = find(id);
        if (!book.getIsbn().equals(req.isbn())) {
            throw new BusinessRuleException("ISBN cannot be changed");
        }
        book.update(req.title().trim(), req.author().trim(), blankToNull(req.genre()),
                req.publishedYear(), req.totalCopies());
        return BookResponse.from(book);
    }

    @Transactional
    public void delete(Long id) {
        Book book = find(id);
        if (loans.existsByBookIdAndReturnedOnIsNull(id)) {
            throw new BusinessRuleException("Cannot delete a book that has copies on loan");
        }
        books.delete(book);
    }

    Book find(Long id) {
        return books.findById(id).orElseThrow(() -> new NotFoundException("Book " + id + " not found"));
    }

    private static String blankToNull(String s) {
        return (s == null || s.isBlank()) ? null : s.trim();
    }
}
