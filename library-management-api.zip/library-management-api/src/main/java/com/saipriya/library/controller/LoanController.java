package com.saipriya.library.controller;

import com.saipriya.library.dto.LoanDtos.BorrowRequest;
import com.saipriya.library.dto.LoanDtos.LoanResponse;
import com.saipriya.library.service.LoanService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loans")
@Tag(name = "Loans")
public class LoanController {

    private final LoanService loanService;

    public LoanController(LoanService loanService) {
        this.loanService = loanService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Borrow a book (checks availability, loan limit and member status)")
    public LoanResponse borrow(@Valid @RequestBody BorrowRequest request) {
        return loanService.borrow(request.memberId(), request.bookId());
    }

    @PostMapping("/{id}/return")
    public LoanResponse returnBook(@PathVariable Long id) {
        return loanService.returnBook(id);
    }

    @GetMapping("/overdue")
    @Operation(summary = "Loans past their due date that haven't been returned")
    public List<LoanResponse> overdue() {
        return loanService.overdue();
    }
}
