package com.saipriya.library.dto;

import com.saipriya.library.entity.Book;
import jakarta.validation.constraints.*;

public final class BookDtos {

    private BookDtos() {
    }

    public record BookRequest(
            @NotBlank @Pattern(regexp = "\\d{10}|\\d{13}", message = "must be 10 or 13 digits") String isbn,
            @NotBlank @Size(max = 200) String title,
            @NotBlank @Size(max = 120) String author,
            @Size(max = 60) String genre,
            @Min(1450) @Max(2100) Integer publishedYear,
            @Min(1) @Max(1000) int totalCopies) {
    }

    public record BookResponse(
            Long id, String isbn, String title, String author, String genre,
            Integer publishedYear, int totalCopies, int availableCopies) {

        public static BookResponse from(Book b) {
            return new BookResponse(b.getId(), b.getIsbn(), b.getTitle(), b.getAuthor(), b.getGenre(),
                    b.getPublishedYear(), b.getTotalCopies(), b.getAvailableCopies());
        }
    }
}
