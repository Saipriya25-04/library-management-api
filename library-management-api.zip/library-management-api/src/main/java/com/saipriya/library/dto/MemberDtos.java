package com.saipriya.library.dto;

import com.saipriya.library.entity.Member;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public final class MemberDtos {

    private MemberDtos() {
    }

    public record CreateMemberRequest(
            @NotBlank @Size(max = 100) String name,
            @NotBlank @Email String email,
            @Pattern(regexp = "^$|^[0-9+\\-() ]{7,20}$", message = "is not a valid phone number") String phone) {
    }

    public record UpdateMemberRequest(
            @NotBlank @Size(max = 100) String name,
            @Pattern(regexp = "^$|^[0-9+\\-() ]{7,20}$", message = "is not a valid phone number") String phone,
            boolean active) {
    }

    public record MemberResponse(Long id, String name, String email, String phone,
                                 LocalDate joinedOn, boolean active) {

        public static MemberResponse from(Member m) {
            return new MemberResponse(m.getId(), m.getName(), m.getEmail(), m.getPhone(),
                    m.getJoinedOn(), m.isActive());
        }
    }
}
