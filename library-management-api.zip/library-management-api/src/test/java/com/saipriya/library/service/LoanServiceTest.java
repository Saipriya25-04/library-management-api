package com.saipriya.library.service;

import com.saipriya.library.dto.LoanDtos.LoanResponse;
import com.saipriya.library.entity.Book;
import com.saipriya.library.entity.Loan;
import com.saipriya.library.entity.Member;
import com.saipriya.library.exception.BusinessRuleException;
import com.saipriya.library.repository.BookRepository;
import com.saipriya.library.repository.LoanRepository;
import com.saipriya.library.repository.MemberRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Clock;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoanServiceTest {

    static final LocalDate TODAY = LocalDate.of(2026, 3, 10);

    @Mock LoanRepository loans;
    @Mock BookRepository books;
    @Mock MemberRepository members;

    LoanService service;
    Member member;
    Book book;

    @BeforeEach
    void setUp() {
        Clock fixed = Clock.fixed(TODAY.atStartOfDay().toInstant(ZoneOffset.UTC), ZoneOffset.UTC);
        service = new LoanService(loans, books, members, fixed, 14, 3);

        member = new Member("Ravi", "ravi@example.com", null);
        member.setId(1L);
        book = new Book("9780134685991", "Effective Java", "Joshua Bloch", "Programming", 2018, 2);
        book.setId(7L);
    }

    @Test
    void borrowDecrementsCopiesAndSetsDueDate() {
        when(members.findById(1L)).thenReturn(Optional.of(member));
        when(books.findById(7L)).thenReturn(Optional.of(book));
        when(loans.save(any(Loan.class))).thenAnswer(inv -> inv.getArgument(0));

        LoanResponse loan = service.borrow(1L, 7L);

        assertThat(loan.dueDate()).isEqualTo(TODAY.plusDays(14));
        assertThat(loan.overdue()).isFalse();
        assertThat(book.getAvailableCopies()).isEqualTo(1);
    }

    @Test
    void cannotBorrowWhenNoCopiesLeft() {
        Book single = new Book("1234567890", "Clean Code", "Robert Martin", null, 2008, 1);
        single.setId(8L);
        single.checkOut();
        when(members.findById(1L)).thenReturn(Optional.of(member));
        when(books.findById(8L)).thenReturn(Optional.of(single));

        assertThatThrownBy(() -> service.borrow(1L, 8L))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("No copies");
        verify(loans, never()).save(any());
    }

    @Test
    void enforcesMaximumActiveLoans() {
        when(members.findById(1L)).thenReturn(Optional.of(member));
        when(books.findById(7L)).thenReturn(Optional.of(book));
        when(loans.countByMemberIdAndReturnedOnIsNull(1L)).thenReturn(3L);

        assertThatThrownBy(() -> service.borrow(1L, 7L))
                .isInstanceOf(BusinessRuleException.class)
                .hasMessageContaining("maximum of 3");
        assertThat(book.getAvailableCopies()).isEqualTo(2);
    }

    @Test
    void inactiveMemberCannotBorrow() {
        member.update("Ravi", null, false);
        when(members.findById(1L)).thenReturn(Optional.of(member));
        when(books.findById(7L)).thenReturn(Optional.of(book));

        assertThatThrownBy(() -> service.borrow(1L, 7L))
                .isInstanceOf(BusinessRuleException.class)
                .hasMessageContaining("inactive");
    }

    @Test
    void returnRestoresCopyAndCannotBeRepeated() {
        book.checkOut();
        Loan loan = new Loan(book, member, TODAY.minusDays(5), 14);
        loan.setId(3L);
        when(loans.findById(3L)).thenReturn(Optional.of(loan));

        LoanResponse returned = service.returnBook(3L);

        assertThat(returned.returnedOn()).isEqualTo(TODAY);
        assertThat(book.getAvailableCopies()).isEqualTo(2);
        assertThatThrownBy(() -> service.returnBook(3L)).isInstanceOf(BusinessRuleException.class);
    }

    @Test
    void overdueFlagsLoansPastDueDate() {
        Loan late = new Loan(book, member, TODAY.minusDays(20), 14);
        when(loans.findByReturnedOnIsNullAndDueDateBeforeOrderByDueDateAsc(TODAY)).thenReturn(List.of(late));

        List<LoanResponse> result = service.overdue();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).overdue()).isTrue();
    }
}
