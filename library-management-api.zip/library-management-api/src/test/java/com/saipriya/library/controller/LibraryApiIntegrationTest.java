package com.saipriya.library.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** Exercises the API over HTTP against an in-memory H2 database. */
@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class LibraryApiIntegrationTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;

    @Test
    void searchSupportsKeywordGenreAndPagination() throws Exception {
        createBook("9780134685991", "Effective Java", "Joshua Bloch", "Programming", 2);
        createBook("9780132350884", "Clean Code", "Robert Martin", "Programming", 1);
        createBook("9780061120084", "To Kill a Mockingbird", "Harper Lee", "Fiction", 3);

        mvc.perform(get("/api/books").param("q", "java"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.content[0].title").value("Effective Java"));

        mvc.perform(get("/api/books").param("genre", "programming").param("size", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", hasSize(1)))
                .andExpect(jsonPath("$.totalElements").value(2))
                .andExpect(jsonPath("$.totalPages").value(2));
    }

    @Test
    void borrowAndReturnWorkflow() throws Exception {
        long bookId = createBook("9780132350884", "Clean Code", "Robert Martin", "Programming", 1);
        long alice = createMember("Alice", "alice@example.com");
        long bob = createMember("Bob", "bob@example.com");

        String loanJson = mvc.perform(post("/api/loans").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"memberId\":" + alice + ",\"bookId\":" + bookId + "}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.bookTitle").value("Clean Code"))
                .andReturn().getResponse().getContentAsString();
        long loanId = json.readTree(loanJson).get("id").asLong();

        // The only copy is out, so Bob is refused.
        mvc.perform(post("/api/loans").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"memberId\":" + bob + ",\"bookId\":" + bookId + "}"))
                .andExpect(status().isConflict());

        mvc.perform(get("/api/books").param("availableOnly", "true"))
                .andExpect(jsonPath("$.content", hasSize(0)));

        mvc.perform(post("/api/loans/" + loanId + "/return"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.returnedOn").exists());

        mvc.perform(get("/api/books/" + bookId))
                .andExpect(jsonPath("$.availableCopies").value(1));

        mvc.perform(get("/api/members/" + alice + "/loans"))
                .andExpect(jsonPath("$.content", hasSize(1)));
    }

    @Test
    void rejectsInvalidInputWithFieldErrors() throws Exception {
        mvc.perform(post("/api/books").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"isbn\":\"abc\",\"title\":\"\",\"author\":\"X\",\"totalCopies\":0}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.isbn").exists())
                .andExpect(jsonPath("$.errors.title").exists())
                .andExpect(jsonPath("$.errors.totalCopies").exists());
    }

    @Test
    void duplicateIsbnAndMissingRecordsReturnClearErrors() throws Exception {
        createBook("9780134685991", "Effective Java", "Joshua Bloch", "Programming", 1);

        mvc.perform(post("/api/books").contentType(MediaType.APPLICATION_JSON)
                        .content(bookJson("9780134685991", "Copy", "Someone", null, 1)))
                .andExpect(status().isConflict());

        mvc.perform(get("/api/books/9999")).andExpect(status().isNotFound());
    }

    private long createBook(String isbn, String title, String author, String genre, int copies) throws Exception {
        String res = mvc.perform(post("/api/books").contentType(MediaType.APPLICATION_JSON)
                        .content(bookJson(isbn, title, author, genre, copies)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return json.readTree(res).get("id").asLong();
    }

    private long createMember(String name, String email) throws Exception {
        String res = mvc.perform(post("/api/members").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"" + name + "\",\"email\":\"" + email + "\"}"))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return json.readTree(res).get("id").asLong();
    }

    private String bookJson(String isbn, String title, String author, String genre, int copies) throws Exception {
        var body = new java.util.HashMap<String, Object>();
        body.put("isbn", isbn);
        body.put("title", title);
        body.put("author", author);
        body.put("genre", genre);
        body.put("publishedYear", 2008);
        body.put("totalCopies", copies);
        return json.writeValueAsString(body);
    }
}
