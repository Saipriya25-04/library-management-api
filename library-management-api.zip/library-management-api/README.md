# Library Management REST API

A REST API for running a small library: a catalog of books, member records, and the borrowing workflow (borrow, return, overdue tracking).

**Tech stack:** Java 17 · Spring Boot 3 · Spring Data JPA / Hibernate · MySQL · Jakarta Validation · springdoc OpenAPI (Swagger UI) · JUnit 5 · Mockito

## Features

- **Book catalog** with create, read, update, and delete. Search by title, author, or ISBN, filter by genre or availability, and sort and page the results.
- **Members** with search and paging. A member can't be deactivated while they still have books out.
- **Borrowing rules:**
  - A book can only be borrowed if a copy is available.
  - Each member can have at most 3 active loans (configurable).
  - Inactive members can't borrow, and a member can't hold two copies of the same book.
  - Loans are due after 14 days (configurable), and `/api/loans/overdue` lists late loans.
- **Concurrency safety:** `@Version` optimistic locking on `Book` means two simultaneous checkouts of the last copy can't both succeed.
- **No N+1 queries:** loan lists use `@EntityGraph` to fetch book and member in the same query.
- **Clear errors:** validation failures return 400 with per-field messages, rule violations return 409, and missing records return 404, all as RFC 7807 `ProblemDetail` JSON.

## API

Interactive docs are at **http://localhost:8081/swagger-ui.html** once the app is running.

| Method | Path | Description |
|---|---|---|
| GET | `/api/books?q=&genre=&availableOnly=&page=&size=&sort=` | Search books (`sort` = title, author, publishedYear) |
| GET | `/api/books/{id}` | Get one book |
| POST | `/api/books` | Add a book |
| PUT | `/api/books/{id}` | Update a book (total copies can't drop below copies on loan) |
| DELETE | `/api/books/{id}` | Delete a book with no copies on loan |
| GET | `/api/members?q=&page=&size=` | List or search members |
| GET | `/api/members/{id}` | Get one member |
| POST | `/api/members` | Register a member |
| PUT | `/api/members/{id}` | Update name, phone, or active status |
| GET | `/api/members/{id}/loans` | A member's loan history |
| POST | `/api/loans` | Borrow: `{"memberId": 1, "bookId": 7}` |
| POST | `/api/loans/{id}/return` | Return a book |
| GET | `/api/loans/overdue` | Loans past their due date |

### Example

```bash
curl -X POST localhost:8081/api/books -H "Content-Type: application/json" \
  -d '{"isbn":"9780134685991","title":"Effective Java","author":"Joshua Bloch","genre":"Programming","publishedYear":2018,"totalCopies":3}'

curl -X POST localhost:8081/api/members -H "Content-Type: application/json" \
  -d '{"name":"Alice","email":"alice@example.com"}'

curl -X POST localhost:8081/api/loans -H "Content-Type: application/json" \
  -d '{"memberId":1,"bookId":1}'
```

## Project structure

```
controller/   REST endpoints and request validation
service/      Business rules (loan limits, availability, due dates)
repository/   Spring Data JPA queries
entity/       Book, Member, Loan
dto/          Request and response records
exception/    Custom exceptions and the global error handler
```

## Running locally

**Requirements:** Java 17+, Maven, Docker (or a local MySQL 8).

```bash
docker compose up -d     # MySQL on port 3306
mvn spring-boot:run      # API on http://localhost:8081
```

Database settings come from `DB_URL`, `DB_USERNAME`, and `DB_PASSWORD`. Loan rules are set with `library.loan-days` and `library.max-active-loans` in `application.properties`.

## Tests

```bash
mvn test
```

- `LoanServiceTest`: unit tests with Mockito and a fixed `Clock`, covering availability, loan limits, inactive members, returns, and overdue detection.
- `LibraryApiIntegrationTest`: HTTP tests with MockMvc and an in-memory H2 database, covering search and paging, the full borrow and return flow, validation errors, and duplicate ISBNs.

GitHub Actions runs the tests on every push.
